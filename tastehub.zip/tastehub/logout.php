<?php
// logout.php
require_once 'includes/conn.php';

// Unset all session variables
$_SESSION = array();

// Destroy Session Cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy session
session_destroy();

// Redirect to Login page
header("Location: login.php");
exit();
?>